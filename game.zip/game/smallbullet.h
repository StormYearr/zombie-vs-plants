#ifndef SMALLBULLET_H
#define SMALLBULLET_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QGraphicsItem>
#include <QTimer>

class SmallBullet : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    SmallBullet(QPointF startPos);

public slots:
    void move();

private:
    int speed = 5; // سرعت حرکت گلوله
};

#endif // SMALLBULLET_H
