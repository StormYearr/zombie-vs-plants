#pragma once

#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>
#include <QTimer>
#include <QObject>
#include <QList>
#include "smallbullet.h" // Include the header for SmallBullet class

class p4 : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    p4();
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event) override;
    void startContinuousShooting();
    void moveItem();
    void startShooting(); // Add a function for shooting
    int health = 0; // Plant's health
    const int damagePerSec = 500; // Damage per second to plant's health
    int sunPointsRequired = 175; // Sun points required to activate
    bool isActive = false; // Is the plant active or not
    int shootInterval = 1000; // Time interval between each shoot (in milliseconds)
    int pointsPerSunflower = 25; // Points collected from each sunflower

private slots:
    void shootPea();
    void updateHealth();

private:
    QTimer* shootingTimer; // Timer for shooting bullets
    QTimer* healthTimer; // Timer for health decrement
    QPointF offset; // Offset for mouse dragging
    bool dragging; // Flag for dragging state

    qreal attackRadius = 2 * 2; // Attack radius squared (2 units radius squared)
};
