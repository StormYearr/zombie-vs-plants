#include "smallbullet.h"
#include <QGraphicsScene>
#include <QTimer>

SmallBullet::SmallBullet(QPointF startPos)
{
    QPixmap bulletImage(":/game/D:/Pictures(1)/images.jpg");
    QPixmap scaledBulletImage = bulletImage.scaled(20, 20, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    setPixmap(scaledBulletImage);
    setPos(startPos);

    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &SmallBullet::move);
    timer->start(50); // هر 50 میلی‌ثانیه یکبار حرکت می‌کند
}

void SmallBullet::move()
{
    // حرکت گلوله به سمت راست
    setPos(x() + speed, y());

    // بررسی برخورد با زامبی‌ها
    //    QList<QGraphicsItem*> collidingItems = this->collidingItems();
    //    for (auto item : collidingItems) {
    //        if (typeid(*item) == typeid(Zombie)) { // فرض بر اینکه کلاس زامبی نامش Zombie است
    //            // حذف گلوله و زامبی (یا کاهش سلامتی زامبی)
    //            scene()->removeItem(item);
    //            scene()->removeItem(this);
    //            delete item;
    //            delete this;
    //            return;
    //        }
    //    }

    // اگر گلوله از صحنه خارج شد، حذف شود
    if (pos().x() > scene()->width()) {
        scene()->removeItem(this);
        delete this;
    }
}
