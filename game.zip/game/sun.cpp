#include "sun.h"
#include <QPixmap>
#include <QTimer>
#include <QDebug>
#include <QGraphicsScene>
#include <QRandomGenerator> // For random number generation
#include <QGraphicsSceneMouseEvent>

extern int collectedSunPoints; // فرض بر اینکه تعداد خورشیدهای جمع‌آوری شده در متغیری خارجی ذخیره می‌شود

sun::sun()
{
    // Set the default size of the sun
    sunSize = QSize(40, 40); // Default size is 40x40

    // Start timer to show sun on different positions
    timerShow = new QTimer(this);
    connect(timerShow, &QTimer::timeout, this, &sun::showRandomPosition);
    timerShow->start(5000); // Timer interval: 5 seconds
}

void sun::setSunSize(const QSize &size)
{
    sunSize = size; // Set the new size for the sun
}

void sun::showRandomPosition()
{
    // List of specific positions on the game board (assuming a grid of 12x6)
    QList<QPointF> positions;
    for (int i = 0; i < 12; ++i) {
        for (int j = 0; j < 6; ++j) {
            positions.append(QPointF(i * 60, j * 60)); // Adjust the step size based on your grid size
        }
    }

    // Get a random index to choose a position
    int randomIndex = QRandomGenerator::global()->bounded(positions.size());
    QPointF randomPosition = positions[randomIndex];

    // Create a new instance of QGraphicsPixmapItem for sun
    QGraphicsPixmapItem *newSunItem = new QGraphicsPixmapItem(QPixmap(":/game/D:/Pictures(1)/sun.png").scaled(sunSize));
    newSunItem->setPos(randomPosition);

    // Add sun item to the scene (assuming you have access to the scene)
    if (scene()) {
        scene()->addItem(newSunItem);

        // Start the timer to hide sun after 3 seconds
        QTimer *timerHideCurrent = new QTimer(this);
        connect(timerHideCurrent, &QTimer::timeout, [newSunItem, timerHideCurrent]() {
            if (newSunItem->scene()) {
                newSunItem->scene()->removeItem(newSunItem);
                delete newSunItem;
            }
            timerHideCurrent->deleteLater();
        });
        timerHideCurrent->start(3000); // Timer interval: 3 seconds
    }
}

void sun::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    // Increase the collected sun points
    collectedSunPoints += 25; // Each sun gives 25 points

    // Remove the sun from the scene
    if (scene()) {
        scene()->removeItem(this);
    }
    delete this;

    QGraphicsPixmapItem::mousePressEvent(event);
}
//#include "sun.h"
//#include <QGraphicsScene>

//extern int collectedSunPoints;

//sun::sun()
//{
//    QPixmap sunImage(":/game/path_to_sun_image.png");
//    setPixmap(sunImage.scaled(50, 50, Qt::KeepAspectRatio, Qt::SmoothTransformation));
//    setPos(QRandomGenerator::global()->bounded(700), QRandomGenerator::global()->bounded(500));

//    // ایجاد تایمر برای نمایش تصادفی
//    timerShow = new QTimer(this);
//    connect(timerShow, &QTimer::timeout, this, &sun::showRandomPosition);
//    timerShow->start(3000); // هر 3 ثانیه خورشید در موقعیتی تصادفی ظاهر می‌شود
//}

//void sun::mousePressEvent(QGraphicsSceneMouseEvent *event)
//{
//    // افزایش امتیاز با کلیک بر روی خورشید
//    collectedSunPoints += 25;
//    qDebug() << "Collected Sun Points: " << collectedSunPoints;

//    // حذف خورشید پس از کلیک
//    scene()->removeItem(this);
//    delete this;
//}

//void sun::showRandomPosition()
//{
//    // تنظیم موقعیت تصادفی خورشید در صحنه
//    setPos(QRandomGenerator::global()->bounded(scene()->width()), QRandomGenerator::global()->bounded(scene()->height()));
//}
