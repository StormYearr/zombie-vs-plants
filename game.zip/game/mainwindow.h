#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "p1.h"
#include "p2.h"
#include "p3.h"
#include "p4.h"
#include "p5.h"
#include "p6.h"
#include "qgraphicsscene.h"
#include "qgraphicsview.h"
#include "sun.h"
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QGraphicsView
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    p1 *pln1;
    p2 *pln2;
    p3 *pln3;
    p4 *pln4;
    p5 *pln5;
    p6 *pln6;
    sun *b;
private:
    QGraphicsScene *view;
    int collectedSunPoints; // تعداد خورشیدهای جمع‌آوری شده

private slots:
    void updateSunPoints(int points);

};
#endif // MAINWINDOW_H
