//#ifndef SUN_H
//#define SUN_H

//#include <QGraphicsItem>
//#include <QGraphicsPixmapItem>
//#include <QGraphicsScene>
//#include <QTimer>
//#include <QSize>
//#include <QGraphicsSceneMouseEvent>
//#include <QObject>
//#include <QRandomGenerator>

//class sun : public QObject, public QGraphicsPixmapItem
//{
//    Q_OBJECT
//public:
//    sun();

//    void setSunSize(const QSize &size);

//protected:
//    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;

//private slots:
//    void showRandomPosition();

//private:
//    QTimer *timerShow;
//    QSize sunSize;
//};

//#endif // SUN_H
#ifndef SUN_H
#define SUN_H

#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
#include <QTimer>
#include <QList>
#include <QSize>
#include <QGraphicsSceneMouseEvent>

class sun : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    sun();

    void setSunSize(const QSize &size);

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;

private slots:
    void showRandomPosition();

private:
    QTimer *timerShow;
    QSize sunSize;
};

#endif // SUN_H
