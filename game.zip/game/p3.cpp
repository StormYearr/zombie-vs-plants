#include "p3.h"
#include "ground.h"
#include "smallbullet.h"
#include <QGraphicsScene>
#include <QCursor>
#include <QDebug>

extern int collectedSunPoints; // فرض بر اینکه تعداد خورشیدهای جمع‌آوری شده در متغیری خارجی ذخیره می‌شود

p3::p3()
{
    QPixmap imagDI2(":/game/D:/walnut_transparent.png");
    QPixmap scaled_imagDI2 = imagDI2.scaled(80, 110, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    setPixmap(scaled_imagDI2);
    setPos(139, 405); // موقعیت اولیه گیاه
    setAcceptHoverEvents(true);

    // شروع تایمر شلیک پس از فعال شدن گیاه
//    shootingTimer = new QTimer(this);
//    connect(shootingTimer, &QTimer::timeout, this, &p3::shootPea);

    // تایمر کاهش سلامتی گیاه
    healthTimer = new QTimer(this);
    connect(healthTimer, &QTimer::timeout, this, &p3::updateHealth);
    healthTimer->start(1000); // هر ثانیه سلامتی کم می‌شود

    dragging = false; // مقدار اولیه برای کشیدن با موس
}

void p3::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    // Capture the position of the cursor relative to the item
    offset = event->pos();
    dragging = true; // شروع کشیدن
}

void p3::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    if (dragging) {
        // Calculate the new position of the item
        QPointF newPos = event->scenePos() - offset;

        // Check if the new position is within the scene boundaries
        QRectF sceneRect = scene()->sceneRect();
        if (sceneRect.contains(newPos)) {
            setPos(newPos);
        }
    }
}

void p3::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    dragging = false; // پایان کشیدن

    // Find the nearest Ground item and snap to its position
    QList<QGraphicsItem*> items = scene()->items();
    qreal minDistance = std::numeric_limits<qreal>::max();
    QPointF nearestPos;

    for (auto item : items) {
        if (auto ground = dynamic_cast<Ground*>(item)) {
            qreal distance = QLineF(mapToScene(boundingRect().center()), ground->mapToScene(ground->boundingRect().center())).length();
            if (distance < minDistance) {
                minDistance = distance;
                nearestPos = ground->pos();
            }
        }
    }

    // Snap to the nearest Ground item
    setPos(nearestPos);

    // Activate shooting after placing the plant
    //startShooting();
}

void p3::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    // Change cursor to indicate item is movable
    QCursor cursor(Qt::OpenHandCursor);
    setCursor(cursor);
}

void p3::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    // Restore default cursor when leaving the item
    unsetCursor();
}

//void p3::startShooting()
//{
//    if (!isActive) {
//        isActive = true;
//        shootingTimer->start(1000); // شروع شلیک‌ها با فاصله زمانی هر ۱ ثانیه
//    }
//}

//void p3::shootPea()
//{
//    // Create a new bullet and add it to the scene
//    QGraphicsScene *scene = this->scene();
//    if (!scene)
//        return;

//    QPointF plantPos = this->pos();
//    QPointF bulletPos(plantPos.x() + 60, plantPos.y() + 25); // موقعیت اولیه گلوله را تنظیم کنید
//    SmallBullet *bullet = new SmallBullet(bulletPos); // SmallBullet را از کلاس مناسب ایجاد کنید

//    // اضافه کردن گلوله به صحنه
//    scene->addItem(bullet);
//}

void p3::updateHealth()
{
    // کاهش سلامتی گیاه هر ثانیه
    if (isActive) {
        health -= damagePerSec;
        if (health <= 0) {
            // اگر سلامتی گیاه تمام شد، گیاه را حذف کنید
            QGraphicsScene *scene = dynamic_cast<QGraphicsScene*>(this->parent());
            if (scene) {
                scene->removeItem(this);
                delete this;
            }
        }
    }
}
