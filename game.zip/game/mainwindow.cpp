#include "mainwindow.h"
#include "p2.h"
#include "ui_mainwindow.h"
#include <QRandomGenerator>
#include <QList>
#include <QFont>
#include "ground.h"
#include "sun.h"
extern int collectedSunPoints = 0; // تعداد خورشیدهای جمع‌آوری شده

MainWindow::MainWindow(QWidget *parent)
    : QGraphicsView(parent)
{
    view = new QGraphicsScene(this);
    setScene(view);
    setFixedSize(800, 600);
    setSceneRect(0, 0, 700, 500);

    QPixmap imageK(":/game/D:/Screenshot (123).png"); // Replace with your actual path
    QGraphicsPixmapItem *itemK = new QGraphicsPixmapItem(imageK);

    // Set position to bottom-left corner
    int xPos = -60;
    int yPos = 400; // Calculate yPos based on scene height and image height
    itemK->setPos(xPos, yPos);

    qreal scaleFactor = 0.55; // Example scale factor (50%)
    itemK->setScale(scaleFactor);
    view->addItem(itemK);

    QPixmap imageK2(":/game/D:/Screenshot (125).png"); // Replace with your actual path
    QGraphicsPixmapItem *itemK2 = new QGraphicsPixmapItem(imageK2);

    // Set position to bottom-left corner
    int xPos2 = 550;
    int yPos2 = 400; // Calculate yPos based on scene height and image height
    itemK2->setPos(xPos2, yPos2);

    // Set scale of the image
    qreal scaleFactor2 = 0.62; // Example scale factor (50%)
    itemK2->setScale(scaleFactor2);
    view->addItem(itemK2);

    // Add ground to the scene
    Ground* G = new Ground();
    view->addItem(G);

    b = new sun();
    view->addItem(b);

    pln1 = new p1();
    view->addItem(pln1);
    pln2 = new p2();
    view->addItem(pln2);
    pln3 = new p3();
    view->addItem(pln3);
    pln4 = new p4();
    view->addItem(pln4);
    pln5 = new p5();
    view->addItem(pln5); // تغییر داده شد به pln5
    pln6 = new p6();
    view->addItem(pln6);
}
