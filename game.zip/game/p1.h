#ifndef P1_H
#define P1_H

#pragma once

#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>
#include <QTimer>
#include <QObject>

class p1 : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    p1();
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event) override;
    void startContinuousShooting();
    void moveItem();
    void startShooting(); // تابعی برای شلیک‌ها اضافه کنید
    int health = 0; // سلامتی گیاه
    const int damagePerSec = 300; // مقداری که از سلامتی گیاه هر ثانیه کم می‌شود
    int sunPointsRequired = 150; // تعداد خورشید‌های مورد نیاز برای فعال شدن
    bool isActive = false; // آیا گیاه فعال است یا خیر
    int shootInterval = 1000; // فاصله‌ی زمانی بین هر شلیک (به میلی‌ثانیه)
    int pointsPerSunflower = 25; // تعداد امتیازی که با جمع‌آوری هر خورشید به دست می‌آید

private slots:
    void shootPea();
    void updateHealth();

private:
    QTimer* shootingTimer; // تایمر برای شلیک‌ها
    QTimer* healthTimer; // تایمر برای کاهش سلامتی
    QPointF offset; // ذخیره کردن اختلاف موقعیت برای کشیدن با موس
    bool dragging; // متغیر برای ذخیره وضعیت کشیدن با موس
};

#endif // P5_H
